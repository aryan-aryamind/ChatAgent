<?php
/**
 * Plugin Name: AI Agent Chatbot
 * Description: Embeds your custom AI Agent Chatbot into your WordPress site as a floating widget.
 * Version: 1.0
 * Author: AI Agent
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ai_agent_embed_chatbot() {
    $agent_id = 'cmmj2xtti00057pugq3ph8r30';
    $base_url = 'https://unchaste-indignant-conception.ngrok-free.dev';
    $embed_url = $base_url . '/chatbot/' . $agent_id;
    ?>
    <style>
        #ai-agent-chatbot-container {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 400px;
            height: 600px;
            z-index: 999999;
            box-shadow: 0 5px 40px rgba(0,0,0,0.16);
            border-radius: 12px;
            overflow: hidden;
            background: white;
            display: none;
        }
        #ai-agent-chatbot-trigger {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 60px;
            height: 60px;
            background: #6366f1;
            border-radius: 50%;
            cursor: pointer;
            z-index: 999999;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            transition: transform 0.3s ease;
        }
        #ai-agent-chatbot-trigger:hover {
            transform: scale(1.1);
        }
        #ai-agent-chatbot-trigger svg {
            width: 30px;
            height: 30px;
            fill: white;
        }
        @media (max-width: 480px) {
            #ai-agent-chatbot-container {
                width: 100%;
                height: 100%;
                bottom: 0;
                right: 0;
                border-radius: 0;
            }
        }
    </style>

    <div id="ai-agent-chatbot-trigger">
        <svg viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/></svg>
    </div>

    <div id="ai-agent-chatbot-container">
        <iframe 
            src="<?php echo esc_url($embed_url); ?>" 
            width="100%" 
            height="100%" 
            style="border:none;"
            allow="clipboard-read; clipboard-write"
        ></iframe>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var trigger = document.getElementById('ai-agent-chatbot-trigger');
            var container = document.getElementById('ai-agent-chatbot-container');
            
            trigger.onclick = function() {
                if (container.style.display === 'none' || container.style.display === '') {
                    container.style.display = 'block';
                } else {
                    container.style.display = 'none';
                }
            };
        });
    </script>
    <?php
}

add_action( 'wp_footer', 'ai_agent_embed_chatbot' );
